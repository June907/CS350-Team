﻿using System;
using System.Collections.Generic;

namespace OOP_Assignment_6
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Member> memberList = new List<Member>();
            Member m = new Member("Erik Halenkamp");
            memberList.Add(m);
            m = new Member("Michael Jackson");
            memberList.Add(m);
            m = new Member("Elvis Presley");
            memberList.Add(m);
            m = new Member("Lady Gaga");
            memberList.Add(m);
            Account a = new UserAccount(true, memberList[0], 10000, 5);
            a = new UserAccount(false, memberList[0], 500, 0);
            a = new UserAccount(true, memberList[1], 1000000, 120);
            a = new UserAccount(true, memberList[1], 59341, 1050);
            a = new UserAccount(false, memberList[1], 12095810, 0);
            a = new UserAccount(true, memberList[2], 0, 0);
            a = new UserAccount(false, memberList[3], 20098, 108);
            Bank ourbank = new Bank(memberList);
            Console.WriteLine(ourbank.getBankBalance());
            ourbank.ListAllMembers();
            Console.WriteLine(ourbank.GetAccountTypeCount());
            Console.WriteLine(ourbank.GetTransactionCount());
            Console.ReadKey();
        }
    }
}

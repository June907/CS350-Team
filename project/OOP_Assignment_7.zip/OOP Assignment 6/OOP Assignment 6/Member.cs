﻿using System;
using System.Collections.Generic;

namespace OOP_Assignment_6
{
	public class Member
	{
		public string name { get; set; }
		private List<Account> accountList;
		public Member(string name)
		{
			this.name = name;
			this.accountList = new List<Account>();
		}

		public List<Account> accList
		{
			get { return this.accountList;  }
			set { this.accountList = value; }
		}

		public void AddAccount(Account account)
		{
			this.accountList.Add(account);
		}


	}
}

﻿using System;
using System.Collections.Generic;

namespace OOP_Assignment_6
{
	public class Bank
	{
		private List<Account> accountList;
		private List<Member> memberList;
		public Bank()
		{
			this.memberList = new List<Member>();
		}

		public Bank(List<Member> memberList)
		{
			this.memberList = memberList;
			updateAccountList();
		}

		public void updateAccountList()
		{
			List<Account> accountList = new List<Account>();
			foreach(Member m in memberList)
			{
				foreach(Account a in m.accountList)
				{
					if (a.isActive())
						accountList.Add(a);
				}
			}
			this.accountList = accountList;
		}

		public double getBankBalance()
		{
			double balance = 0;
			updateAccountList();
			foreach (Account a in accountList) {
				if (a.isActive())
					balance += a.balance();
			}
			return balance;
		}

		public void ListAllMembers()
		{
			foreach (Member m in memberList)
			{
				int accountcount = 0;
				foreach (Account a in m.accountList)
				{
					accountcount += 1;
				}
				Console.WriteLine(m.name + ": " + accountcount + " accounts opened.");
			}
		}

		public Tuple<int,int> GetAccountTypeCount()
		{
			int checkingcount = 0;
			int savingcount = 0;
			updateAccountList();
			foreach (Account a in accountList)
			{
				if (a.isActive() && a.isChecking())
					checkingcount += 1;
				else if (a.isActive() && !a.isChecking())
					savingcount += 1;
			}
			return new Tuple<int, int>(checkingcount, savingcount);
		}

		public int GetTransactionCount()
		{
			int transactioncount = 0;
			updateAccountList();
			foreach (Account a in accountList)
			{
				if (a.isActive())
					transactioncount += a.transactionCount();
			}
			return transactioncount;
		}
	}
}

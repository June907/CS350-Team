﻿using System;


namespace OOP_Assignment_6
{
    public abstract class Account
    {
        public abstract double balance();
        public abstract Member owner();
        public abstract Boolean isChecking();
        public abstract int transactionCount();
        public abstract Boolean isActive();
    }

    class UserAccount : Account
    {
        private double currentbalance;
        private Member currentowner;
        private Boolean isCheckingBool;
        private int currentTransactionCount;
        private Boolean isActiveBool;

        public UserAccount(Boolean isChecking, Member owner, double balance, int currentTransactionCount)
        {
            this.isCheckingBool = isChecking;
            this.currentbalance = balance;
            this.currentowner = owner;
            this.currentTransactionCount = currentTransactionCount;
            this.isActiveBool = true;
            owner.AddAccount(this);
        }

        public void CloseAccount()
        {
            this.isActiveBool = false;
        }

        public void AddFunds(double newfunds)
        {
            this.currentbalance += newfunds;
        }

        public override double balance()
        {
            return this.currentbalance;
        }
        public override Member owner()
        {
            return this.currentowner;
        }
        public override Boolean isChecking()
        {
            return this.isCheckingBool;
        }
        public override int transactionCount()
        {
            return this.currentTransactionCount;
        }
        public override Boolean isActive()
        {
            return this.isActiveBool;
        }
    }

}


